import Foundation

protocol ShapeClicked: AnyObject {
    func shapeClicked(shape: ShapeClass)
}
